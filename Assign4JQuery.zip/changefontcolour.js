 function changefont()
            {

                var x = document.getElementById("cn");
                x.style.fontSize = "20px";           
                x.style.color = "red"; 
            }